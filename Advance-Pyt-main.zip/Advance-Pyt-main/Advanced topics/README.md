# Advanced-Programming-with-Python

# Python/PIL Resize all images in a folder
You can resize multiple images in Python with the awesome PIL library and a small help of the os (operating system) library. By using os. listdir() function you can read all the file names in a directory. After that, all you have to do is to create a for loop to open, resize and save each image in the directory.
the file ResizeAllImages.ipynb countain the code in which you can resize all all the images in given directory.

# Convert JSON to CSV in Python

uisng JsonToCSV.ipynb you can convert Jason to CSV.

